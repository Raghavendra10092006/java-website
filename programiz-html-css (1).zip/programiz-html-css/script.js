let donorRegistry = {};

function registerDonor() {

    let donor = {
        name: document.getElementById("name").value,
        id: document.getElementById("id").value,
        age: document.getElementById("age").value,
        phone: document.getElementById("phone").value,
        city: document.getElementById("city").value,
        bloodType: document.getElementById("bloodType").value,
        available: document.getElementById("available").checked
    };

    if (!donorRegistry[donor.bloodType]) {
        donorRegistry[donor.bloodType] = [];
    }

    donorRegistry[donor.bloodType].push(donor);

    alert("Donor Registered Successfully!");
}

function searchDonor() {

    let bloodType = document.getElementById("searchBlood").value;
    let city = document.getElementById("searchCity").value;

    let donors = donorRegistry[bloodType];
    let output = "";

    if (!donors) {
        output = "<p>No donors found.</p>";
    } else {

        let found = false;

        donors.forEach(donor => {

            if (
                donor.city.toLowerCase() === city.toLowerCase()
                && donor.available
            ) {

                output += `
                <div class="card">
                    <b>${donor.name}</b><br>
                    ID: ${donor.id}<br>
                    Age: ${donor.age}<br>
                    Phone: ${donor.phone}<br>
                    City: ${donor.city}<br>
                    Blood Type: ${donor.bloodType}
                </div>
                `;

                found = true;
            }
        });

        if (!found) {
            output = "<p>No available donors found.</p>";
        }
    }

    document.getElementById("results").innerHTML = output;
}